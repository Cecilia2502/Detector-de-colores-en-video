import cv2
import numpy as np
 
captura = cv2.VideoCapture(0)
 
while(1):
     
    _, imagen = captura.read()
    hsv = cv2.cvtColor(imagen, cv2.COLOR_BGR2HSV)
 
    amarillo_bajos = np.array([20,50,50], dtype=np.uint8)
    amarillo_altos = np.array([40,255,255], dtype=np.uint8)

    azul_bajos = np.array([100,100,20], dtype=np.uint8)
    azul_altos = np.array([122,255,255], dtype=np.uint8)


    rojo_bajos = np.array([170,140,65], dtype=np.uint8)
    rojo_altos = np.array([180,255,245], dtype=np.uint8)
    rojo_bajos1 = np.array([171,100,20], dtype=np.uint8)
    rojo_altos1 = np.array([183,255,255], dtype=np.uint8)
    

    maskA = cv2.inRange(hsv, amarillo_bajos, amarillo_altos)
    maskB = cv2.inRange(hsv, azul_bajos, azul_altos)
    maskC = cv2.inRange(hsv, rojo_bajos, rojo_altos)
    maskD = cv2.inRange(hsv, rojo_bajos1,rojo_altos1)
    maskE = maskA + maskB + maskC + maskD
    
    moments = cv2.moments(maskE)
    area = moments['m00']
 
    if(area > 2000000):
         
        x = int(moments['m10']/moments['m00'])
        y = int(moments['m01']/moments['m00'])
         
        print ("x = ", x)
        print ("y = ", y)
 
        cv2.rectangle(imagen, (x, y), (x+2, y+2),(0,0,255), 2)
     
    cv2.imshow("DETECTOR DE COLORES", maskE)
    cv2.imshow("CAMARA", imagen)
    tecla = cv2.waitKey(5) & 0xFF
    if tecla == 27:
        break
 
cv2.destroyAllWindows()

